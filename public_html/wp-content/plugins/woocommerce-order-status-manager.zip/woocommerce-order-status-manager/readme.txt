=== WooCommerce Order Status Manager ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.0
Tested up to: 4.4.1
Requires WooCommerce at least: 2.3.6
Tested WooCommerce up to: 2.5.0

Easily create custom order statuses and trigger custom emails when order status changes

See http://docs.woothemes.com/document/woocommerce-order-status-manager/ for full documentation.

== Installation ==

1. Upload the entire 'wocoommerce-order-status-manager' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
